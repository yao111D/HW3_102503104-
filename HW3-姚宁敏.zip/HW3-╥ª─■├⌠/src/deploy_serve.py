import os
os.environ["SGLANG_DISABLE_FLASHINFER_JIT"] = "1"
os.environ["SGLANG_DISABLE_JIT"] = "1"

import ray
from ray import serve
from fastapi import FastAPI, Request
from fastapi.responses import Response
import subprocess
import time
import aiohttp
import random
import requests
import hashlib
import json

ray.init(num_cpus=80, ignore_reinit_error=True)
serve.start(http_options={"host": "0.0.0.0", "port": 8000})

app = FastAPI()
MODEL_PATH = "/root/autodl-tmp/Qwen3-0.6B"

ROUTER_MODE = "improved"
MAX_ONGOING_REQUESTS = 3

def start_sglang_backends():
    procs = []
    for i in range(4):
        port = 30000 + i
        env = os.environ.copy()
        env["CUDA_VISIBLE_DEVICES"] = str(i)
        env["SGLANG_DISABLE_JIT"] = "1"
        env["SGLANG_DISABLE_FLASHINFER_JIT"] = "1"
        cmd = f"python -m sglang.launch_server --model-path {MODEL_PATH} --port {port} --mem-fraction-static 0.5 --disable-flashinfer-cutlass --disable-cuda-graph --attention-backend triton"
        print(f"正在启动后端 {i}，端口 {port}...")
        log_file = open(f"/root/autodl-tmp/sglang_{i}.log", "w")
        p = subprocess.Popen(cmd, shell=True, env=env, stdout=log_file, stderr=log_file)
        procs.append(p)
        time.sleep(2)
    return procs

@serve.deployment(num_replicas=4, max_ongoing_requests=MAX_ONGOING_REQUESTS)
class Router:
    def __init__(self):
        self.backends = [f"http://127.0.0.1:{30000+i}" for i in range(4)]
        self.active_requests = [0] * 4
        self.counts = [0] * 4

    async def __call__(self, request: Request):
        body = await request.body()
        if ROUTER_MODE == "p2c":
            idx1, idx2 = random.sample(range(4), 2)
            idx = idx1 if self.active_requests[idx1] <= self.active_requests[idx2] else idx2
        elif ROUTER_MODE == "affinity":
            idx = int(hashlib.md5(body).hexdigest(), 16) % 4
        elif ROUTER_MODE == "improved":
            affinity_idx = int(hashlib.md5(body).hexdigest(), 16) % 4
            if self.active_requests[affinity_idx] < 3:
                idx = affinity_idx
            else:
                idx1, idx2 = random.sample(range(4), 2)
                idx = idx1 if self.active_requests[idx1] <= self.active_requests[idx2] else idx2
        target = self.backends[idx]
        self.counts[idx] += 1
        async with aiohttp.ClientSession() as session:
            try:
                async with session.post(target + "/generate", data=body, headers=request.headers) as resp:
                    response_body = await resp.read()
                    return Response(content=response_body, status_code=resp.status, headers=dict(resp.headers))
            except Exception as e:
                return Response(content=str(e), status_code=500)

if __name__ == "__main__":
    print(f"当前路由模式: {ROUTER_MODE}, 最大并发: {MAX_ONGOING_REQUESTS}")
    start_sglang_backends()
    for i in range(4):
        port = 30000 + i
        url = f"http://127.0.0.1:{port}/health"
        while True:
            try:
                r = requests.get(url, timeout=2)
                if r.status_code == 200:
                    print(f"后端 {port} 已就绪。")
                    break
            except:
                time.sleep(5)
    serve.run(Router.bind())
    print("部署完成！请另开终端运行 my_test.py")
    while True:
        time.sleep(10)