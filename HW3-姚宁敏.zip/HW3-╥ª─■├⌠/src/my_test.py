import requests
import time
import json
import random
import concurrent.futures
from collections import Counter

BACKENDS = [f"http://127.0.0.1:{30000+i}" for i in range(4)]
TOTAL_REQUESTS = 2048
MAX_WORKERS = 10

def make_request(req_id):
    r = random.random()
    if r < 0.9:
        prefix_id = random.choice([1, 2, 3])
    else:
        prefix_id = random.randint(10, 100)
    idx = hash(prefix_id) % 4
    target = BACKENDS[idx]
    payload = {
        "text": f"这是一个共享的前缀段落，编号 {prefix_id}，请随便写一段话。",
        "sampling_params": {"max_new_tokens": 10}
    }
    start_time = time.time()
    try:
        resp = requests.post(f"{target}/generate", json=payload, timeout=30)
        latency = time.time() - start_time
        if resp.status_code == 200:
            return {"id": req_id, "success": True, "latency": latency, "backend": target}
        else:
            return {"id": req_id, "success": False, "latency": latency, "error": resp.status_code}
    except Exception as e:
        return {"id": req_id, "success": False, "latency": time.time() - start_time, "error": str(e)}

print("开始发送压测请求...")
results = []
with concurrent.futures.ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
    futures = [executor.submit(make_request, i) for i in range(TOTAL_REQUESTS)]
    for i, future in enumerate(concurrent.futures.as_completed(futures)):
        results.append(future.result())
        if (i+1) % 200 == 0:
            print(f"已完成 {i+1}/{TOTAL_REQUESTS} 个请求...")
success_count = sum(1 for r in results if r["success"])
success_rate = success_count / TOTAL_REQUESTS * 100
avg_latency = sum(r["latency"] for r in results if r["success"]) / success_count if success_count > 0 else 0

backend_counts = Counter([r["backend"] for r in results if r.get("success")])
print(f"\n========== D 组实验结果（改进路由） ==========")
print(f"成功率: {success_rate:.2f}%")
print(f"平均延迟: {avg_latency:.4f} 秒")
print(f"后端请求分布: {json.dumps(dict(backend_counts), indent=2)}")
print("结果已保存")

with open("results/target3/D_results.json", "w") as f:
    json.dump({
        "success_rate": success_rate, 
        "avg_latency": avg_latency, 
        "backend_distribution": dict(backend_counts),
        "raw_results": results
    }, f, indent=2)
print("结果已保存到 results/target3/D_results.json")