# HW3 - 挑战三：比较并改进 RayServe 路由

## 环境依赖

- GPU: 4 × RTX 4090
- CUDA: 12.1, Python 3.10
- 依赖: `pip install -r requirements.txt`

## 启动方法

### 1. 启动服务端 (4个SGLang副本 + RayServe)

python deploy_serve.py

### 2. 在另一个终端启动压测

python my_test.py

## 结果目录说明

- `results/target3/A_default/` -> A 组默认 P2C 数据
- `results/target3/B_candidates/` -> B 组调参数据
- `results/target3/C_affinity/` -> C 组纯前缀亲和数据
- `results/target3/D_improved/` -> D 组改进路由数据
